import { useState } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Header from './components/Header';
import DocumentationForm from './components/DocumentationForm';

interface DocumentationData {
  patientRoom: string;
  inputMode: 'text' | 'voice';
  content: string;
  optimizationLevel: 'quick' | 'full';
}

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('Max Mustermann');
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [analysisResult, setAnalysisResult] = useState<DocumentationData | null>(null);

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentPage('dashboard');
  };

  const handleNewDocumentation = () => {
    setCurrentPage('documentation');
    setAnalysisResult(null);
  };

  const handleAnalyze = (data: DocumentationData) => {
    setAnalysisResult(data);
  };

  return (
    <>
      {!isLoggedIn ? (
        <Login onLogin={handleLogin} />
      ) : (
        <>
          <Header username={username} onLogout={handleLogout} />
          {currentPage === 'dashboard' && (
            <Dashboard username={username} onNewDocumentation={handleNewDocumentation} />
          )}
          {currentPage === 'documentation' && (
            <DocumentationForm onAnalyze={handleAnalyze} />
          )}
        </>
      )}
    </>
  );
}

export default App;
