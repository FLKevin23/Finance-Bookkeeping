import { useState } from 'react';

interface LoginProps {
  onLogin: () => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError('Bitte füllen Sie beide Felder aus');
      return;
    }

    onLogin();
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#F8F8F8' }}>
      <div className="w-full max-w-md px-6">
        <div className="bg-white rounded shadow-sm p-8">
          <h1 className="text-[28px] font-bold mb-6" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
            Einloggen
          </h1>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="text"
                placeholder="Benutzername"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <input
                type="password"
                placeholder="Passwort"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {error && (
              <p className="text-red-500 text-sm">{error}</p>
            )}

            <button
              type="submit"
              className="w-full py-3 text-white font-medium rounded transition-colors"
              style={{ backgroundColor: '#007AFF' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#0051D5'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#007AFF'}
            >
              Einloggen
            </button>

            <div className="text-center">
              <a
                href="#"
                className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                onClick={(e) => e.preventDefault()}
              >
                Passwort zurücksetzen
              </a>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
