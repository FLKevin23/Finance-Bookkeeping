import { useState } from 'react';
import { Mic } from 'lucide-react';

interface DocumentationFormProps {
  onAnalyze: (data: DocumentationData) => void;
}

interface DocumentationData {
  patientRoom: string;
  inputMode: 'text' | 'voice';
  content: string;
  optimizationLevel: 'quick' | 'full';
}

export default function DocumentationForm({ onAnalyze }: DocumentationFormProps) {
  const [patientRoom, setPatientRoom] = useState('');
  const [inputMode, setInputMode] = useState<'text' | 'voice'>('text');
  const [content, setContent] = useState('');
  const [optimizationLevel, setOptimizationLevel] = useState<'quick' | 'full'>('full');
  const [isRecording, setIsRecording] = useState(false);

  const maxLength = 2000;
  const charCount = content.length;

  const handleAnalyze = () => {
    if (!patientRoom.trim() || !content.trim()) {
      alert('Bitte füllen Sie alle erforderlichen Felder aus');
      return;
    }

    onAnalyze({
      patientRoom: patientRoom.trim(),
      inputMode,
      content: content.trim(),
      optimizationLevel,
    });
  };

  const handleRecordClick = () => {
    setIsRecording(!isRecording);
  };

  return (
    <div className="min-h-screen pt-20" style={{ backgroundColor: '#F8F8F8' }}>
      <div className="container mx-auto px-6 py-8">
        <h1 className="text-[28px] font-bold mb-8" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
          Neue Dokumentation
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold mb-2" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
                Patient / Zimmer
              </label>
              <input
                type="text"
                value={patientRoom}
                onChange={(e) => setPatientRoom(e.target.value)}
                placeholder="z.B. Zimmer 101 - Max Mustermann"
                className="w-full px-4 py-3 border border-gray-300 rounded"
                style={{ backgroundColor: '#FFFFFF', borderColor: '#CCC' }}
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
                Eingabemodus
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setInputMode('text')}
                  className="flex-1 py-3 px-4 rounded font-medium transition-colors"
                  style={{
                    backgroundColor: inputMode === 'text' ? '#007AFF' : '#E0E0E0',
                    color: inputMode === 'text' ? '#FFFFFF' : '#333333',
                  }}
                >
                  Text eingeben
                </button>
                <button
                  onClick={() => setInputMode('voice')}
                  className="flex-1 py-3 px-4 rounded font-medium transition-colors"
                  style={{
                    backgroundColor: inputMode === 'voice' ? '#007AFF' : '#E0E0E0',
                    color: inputMode === 'voice' ? '#FFFFFF' : '#333333',
                  }}
                >
                  Sprache aufnehmen
                </button>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-semibold" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
                  Dokumentation
                </label>
                <span className="text-xs text-gray-500">
                  {charCount} / {maxLength}
                </span>
              </div>
              <textarea
                value={content}
                onChange={(e) => {
                  if (e.target.value.length <= maxLength) {
                    setContent(e.target.value);
                  }
                }}
                placeholder="Beschreibe kurz, was du für den Bewohner gemacht hast..."
                className="w-full px-4 py-3 border border-gray-300 rounded"
                style={{
                  backgroundColor: '#FFFFFF',
                  borderColor: '#CCC',
                  minHeight: '300px',
                  fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',
                  resize: 'vertical',
                }}
              />
            </div>

            {inputMode === 'voice' && (
              <button
                onClick={handleRecordClick}
                className="w-full py-4 px-4 rounded font-semibold flex items-center justify-center gap-3 transition-colors text-white"
                style={{
                  backgroundColor: isRecording ? '#FF3B30' : '#007AFF',
                }}
              >
                <Mic size={20} />
                {isRecording ? 'Aufnahme läuft...' : 'Aufnahme starten'}
              </button>
            )}

            <div>
              <label className="block text-sm font-semibold mb-3" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
                Optimierungslevel
              </label>
              <div className="space-y-2">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="optimization"
                    value="quick"
                    checked={optimizationLevel === 'quick'}
                    onChange={() => setOptimizationLevel('quick')}
                    className="w-4 h-4"
                  />
                  <span className="text-sm">Schnellprüfung</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="optimization"
                    value="full"
                    checked={optimizationLevel === 'full'}
                    onChange={() => setOptimizationLevel('full')}
                    className="w-4 h-4"
                  />
                  <span className="text-sm">Volle Optimierung</span>
                </label>
              </div>
            </div>

            <button
              onClick={handleAnalyze}
              className="w-full py-3 px-4 rounded font-semibold text-white transition-colors"
              style={{ backgroundColor: '#007AFF' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#0051D5'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#007AFF'}
            >
              Analysieren & Optimieren
            </button>
          </div>

          <div className="bg-white rounded shadow-sm p-8" style={{ backgroundColor: '#FFFFFF' }}>
            <div className="text-center text-gray-400 py-12">
              <p>Optimierungsergebnisse werden hier angezeigt</p>
              <p className="text-xs mt-2">(Schritt 4)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
