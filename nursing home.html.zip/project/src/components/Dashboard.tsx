import { FileText, History } from 'lucide-react';

interface DashboardProps {
  username: string;
  onNewDocumentation: () => void;
}

export default function Dashboard({ username, onNewDocumentation }: DashboardProps) {
  return (
    <div className="min-h-screen pt-20" style={{ backgroundColor: '#F8F8F8' }}>
      <div className="container mx-auto px-6 py-8">
        <h1 className="text-[28px] font-bold mb-8" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
          Willkommen, {username}
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <button
            onClick={onNewDocumentation}
            className="bg-white rounded shadow-sm p-8 hover:shadow-md transition-shadow text-left"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded flex items-center justify-center flex-shrink-0">
                <FileText size={24} className="text-blue-500" />
              </div>
              <div>
                <h2 className="text-lg font-semibold" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
                  Neue Dokumentation
                </h2>
                <p className="text-sm text-gray-600">Erstelle einen neuen Dokumentationseintrag</p>
              </div>
            </div>
          </button>

          <button
            className="bg-white rounded shadow-sm p-8 hover:shadow-md transition-shadow text-left border-2 border-gray-200"
            style={{ backgroundColor: '#FFFFFF' }}
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gray-100 rounded flex items-center justify-center flex-shrink-0">
                <History size={24} className="text-gray-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
                  Historie
                </h2>
                <p className="text-sm text-gray-600">Übersicht aller Einträge</p>
              </div>
            </div>
          </button>
        </div>

        <div className="bg-white rounded shadow-sm p-8">
          <h3 className="text-lg font-semibold mb-4" style={{ fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif' }}>
            Statistiken
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-gray-600 text-sm mb-2">Heute dokumentiert</p>
              <p className="text-3xl font-bold text-blue-500">12</p>
              <p className="text-gray-500 text-xs mt-1">Einträge</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm mb-2">Diese Woche</p>
              <p className="text-3xl font-bold text-blue-500">48</p>
              <p className="text-gray-500 text-xs mt-1">Einträge</p>
            </div>
            <div>
              <p className="text-gray-600 text-sm mb-2">Gesamt</p>
              <p className="text-3xl font-bold text-blue-500">342</p>
              <p className="text-gray-500 text-xs mt-1">Einträge</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
